var app  = angular.module('CheckNumberApp', []);

app.controller('CheckNumberController', function CheckNumberController($scope) {

	$scope.checkNumber  = {
			wholeNumber: function(x) {
				if (x % 2 == 0) {
					return 'Yes, Given Number Is A Whole Number';
				} else {
					return 'No, Given Number Is Not A Whole Number';
				}
			},
			oddOrEven: function(x) {
				if (x%2) {
					return "Given Number Is A Odd Number";
				} else { 
					return "Given Number Is A Even Number";
				}
			}
		}
  
});

