describe('CheckNumber', function () {

	  beforeEach(module('CheckNumberApp'));

	  var $controller;

	  beforeEach(inject(function(_$controller_){
		$controller = _$controller_;
	  }));
	  
		describe('CheckNumber', function () {
				
			it('Check Given Number Is A Whole Number', function () {
			    var $scope = {};
				var controller = $controller('CheckNumberController', { $scope: $scope });
				expect($scope.checkNumber.wholeNumber(11.5)).toBe('No, Given Number Is Not A Whole Number');
			});
			
			it('Check Given Number Is A Odd Or Even Number', function () {
				var $scope = {};
				var controller = $controller('CheckNumberController', { $scope: $scope });
				expect($scope.checkNumber.oddOrEven(10)).toBe('Given Number Is A Even Number');
			});

		});

	});